package com.minhhung.apporderfood.DTO;

/**
 * Created by Nhox on 4/6/2016.
 */
public class ThanhToanDTO {
    String TenMonAn;
    int SoLuong,GiaTien;

    public String getTenMonAn() {
        return TenMonAn;
    }

    public void setTenMonAn(String tenMonAn) {
        TenMonAn = tenMonAn;
    }

    public int getSoLuong() {
        return SoLuong;
    }

    public void setSoLuong(int soLuong) {
        SoLuong = soLuong;
    }

    public int getGiaTien() {
        return GiaTien;
    }

    public void setGiaTien(int giaTien) {
        GiaTien = giaTien;
    }


}
