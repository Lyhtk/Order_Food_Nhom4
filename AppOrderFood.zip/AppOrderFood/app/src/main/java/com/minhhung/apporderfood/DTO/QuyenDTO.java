package com.minhhung.apporderfood.DTO;

/**
 * Created by Nhox on 4/18/2016.
 */
public class QuyenDTO {
    int MaQuyen;
    String TenQuyen;

    public int getMaQuyen() {
        return MaQuyen;
    }

    public void setMaQuyen(int maQuyen) {
        MaQuyen = maQuyen;
    }

    public String getTenQuyen() {
        return TenQuyen;
    }

    public void setTenQuyen(String tenQuyen) {
        TenQuyen = tenQuyen;
    }


}
